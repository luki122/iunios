package com.gionee.autommi;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;

public class GyroSensorTest extends BaseActivity implements SensorEventListener{
   
	
	private TextView tip;
	private SensorManager sensorManager;
	private Sensor sensor;
	public static String TAG = "GyroTest";
    private String res;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.tip);
		tip = (TextView) this.findViewById(R.id.tip);
		sensorManager = (SensorManager) this.getSystemService(Context.SENSOR_SERVICE);
		sensor = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
		if (null == sensor) {
			this.finish();
		}
	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		((AutoMMI)getApplication()).recordResult(TAG, "", "0");
		sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_UI);
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		sensorManager.unregisterListener(this);
        this.finish();
	}

	@Override
	public void onSensorChanged(SensorEvent event) {
		// TODO Auto-generated method stub
        float x = event.values[0]; 
        float y = event.values[1];
        float z = event.values[2]; 
		String t = "X : " + x + "\n"
				    + "Y : " + y + "\n"
				    + "Z : " + z + "\n";		
		tip.setText(t);
        if (null == res) {
             res = "" + x + "|" + y + "|" + z;
		    ((AutoMMI)getApplication()).recordResult(TAG, res, "1");
        }
	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {
		// TODO Auto-generated method stub
		
	}

}
