package com.gionee.autommi;

public class Mic_3_Test extends MicTest {

	@Override
	protected void chooseMic() {
		// TODO Auto-generated method stub
		am.setParameters("MMIMic=4");
	}

}
