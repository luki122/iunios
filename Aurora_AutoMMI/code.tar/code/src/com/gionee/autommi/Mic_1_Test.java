package com.gionee.autommi;

public class Mic_1_Test extends MicTest {

	@Override
	protected void chooseMic() {
		// TODO Auto-generated method stub
		am.setParameters("MMIMic=1");
	}
}
